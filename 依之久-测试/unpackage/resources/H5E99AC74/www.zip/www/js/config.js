var config={
	url:"http://wskmlapi.yizhijiu.com/api/ws/" ,
	urlPic:"http://wskmlapi.yizhijiu.com/api/pic/" ,
	urlPicRoot:"http://wskmlapi.yizhijiu.com/Images/" ,
	reqSys:'CN'
}

var tempJson = {
	menu:{
		sale_CN:"我的销售",
		agent_CN:"我的代理",		
		bonus_CN:"我的钱包",
		purchase_CN:"我的采购",
		loginPassword_CN:"登录密码",
		cashPassword_CN:"提现密码",
		info_CN:"我的信息",
		exit_CN:"退出系统",
		myTeam_CN:"我的团队"
	},
	system:"CN",
	msgAgent:"代理添加成功！",
	msgSale:"销售添加成功！",
	msgNoData:"没有相关数据了！",
	msgBonus:"提现申请提交成功！",
	msgBonusForOther:"转账申请提交成功！",
	msgInfoUp:"我的信息修改成功！",
	msgLoginPasswordUp:"登录密码修改成功",
	msgCashPasswordUp:"提现密码修改成功"
}